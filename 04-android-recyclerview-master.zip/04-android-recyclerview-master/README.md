# 04-android-recyclerview

Buat project baru dengan nama 04 Android RecyclerView dan nama repository GitHub: 04-android-recyclerview

## Screenshot Hasil Praktikum

![Hasil Praktikum](screenshots/01.png)
