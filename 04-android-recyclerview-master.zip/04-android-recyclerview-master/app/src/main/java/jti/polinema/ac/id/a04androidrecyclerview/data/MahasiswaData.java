package jti.polinema.ac.id.a04androidrecyclerview.data;

public class MahasiswaData {

    public static String dataMahasiswa(){
        return "[" +
                "{'name': 'ABDULAH SYAHRONY KURNIAWAN', 'nim': '2041720037'}," +
                "{'name': 'ALFINZA SANJAYA PUTRA', 'nim': '2041720186'}," +
                "{'name': 'ALIYAH HANUN SOESHANTONO', 'nim': '1941720175'}," +
                "{'name': 'ANA QONITAH MUNAWWAROH', 'nim': '2041720118'}," +
                "{'name':'ANNISA AULIA NADHILA', 'nim': '2041720023'}," +
                "{'name':'ARYA ADMAJA', 'nim': '2041720104'}," +
                "{'name':'DIO AULIA ARI KURNIA SANDI', 'nim': '2041720086'}," +
                "{'name':'DWI MARIA ULFA', 'nim': '2041720139'}," +
                "{'name':'HALDA DINI SILMA ROSIDA', 'nim': '2041720014'}," +
                "{'name':'ILHAM LUTFIANSYAH', 'nim': '2041720025'}," +
                "{'name':'JUD AMAL MUKHTAR', 'nim': '2041720168'}," +
                "{'name':'KARMILA NOVI ARFIANA', 'nim': '2041720073'}," +
                "{'name':'MILA YUNITA', 'nim': '2041720027'}," +
                "{'name':'MOKHAMAD DWIHARDIK KUSUMA PUTRA', 'nim': '2041720256'}," +
                "{'name':'MUHAMMAD REZA KHATAMI', 'nim': '2041720076'}," +
                "{'name':'MUHAMMAD HAMAMIY ZADAH', 'nim': '2041720028'}," +
                "{'name':'OKTAVIAN VANDI TRI SHAKTI', 'nim': '2041720208'}," +
                "{'name':'PRANATA DITO FITRIYANSYAH', 'nim': '2041720043'}," +
                "{'name':'QALBII AZZAHRA PUTRA', 'nim': '2041720252'}," +
                "{'name':'RARA DENINDA HURIANTO', 'nim': '2041720110'}," +
                "{'name':'SHINE DEVI OKTAVIANA RONIX SYAH PUTRI', 'nim': '2041720065'}," +
                "{'name':'SILVIA PRADA APRILIA', 'nim': '2041720141'}," +
                "{'name':'WELSON MARIO NAIBAHO', 'nim': '2041720253'}," +
                "{'name':'YANU MIFTAHUL HABIBILLAH', 'nim': '2041720251'}," +
                "{'name':'YUDAS MALABI', 'nim': '2041720054'}," +
                "{'name':'YULIA EKA ARDHANI', 'nim': '2041720064'}" +
                "]";
    }

}
